# TOPSIS - Rhythm (102303707)

A Python package to perform Multi-Criteria Decision Making using the TOPSIS method.

## Installation
```bash
pip install topsis-rhythm-102303707
